const canvas = document.getElementById('game');
const ctx = canvas.getContext('2d');
const scoreElement = document.getElementById('score');
const bestElement = document.getElementById('best');
const message = document.getElementById('message');
const messageTitle = document.getElementById('messageTitle');
const messageText = document.getElementById('messageText');
const cellSize = 20;
const cells = canvas.width / cellSize;
const tickLength = 115;

let snake;
let direction;
let nextDirection;
let food;
let score;
let gameOver;
let lastTick = 0;
let bestScore = Number(localStorage.getItem('snake-best') || 0);
bestElement.textContent = bestScore;

function resetGame() {
  snake = [{ x: 10, y: 10 }, { x: 9, y: 10 }, { x: 8, y: 10 }];
  direction = { x: 1, y: 0 };
  nextDirection = direction;
  score = 0;
  gameOver = false;
  scoreElement.textContent = score;
  message.hidden = true;
  placeFood();
  draw();
}

function placeFood() {
  do {
    food = { x: Math.floor(Math.random() * cells), y: Math.floor(Math.random() * cells) };
  } while (snake.some((part) => part.x === food.x && part.y === food.y));
}

function setDirection(x, y) {
  if (x !== -direction.x || y !== -direction.y) {
    nextDirection = { x, y };
  }
}

function step() {
  direction = nextDirection;
  const head = { x: snake[0].x + direction.x, y: snake[0].y + direction.y };
  const eating = head.x === food.x && head.y === food.y;
  const bodyToCheck = eating ? snake : snake.slice(0, -1);

  if (
    head.x < 0 || head.x >= cells || head.y < 0 || head.y >= cells ||
    bodyToCheck.some((part) => part.x === head.x && part.y === head.y)
  ) {
    endGame();
    return;
  }

  snake.unshift(head);
  if (eating) {
    score += 1;
    scoreElement.textContent = score;
    if (score > bestScore) {
      bestScore = score;
      bestElement.textContent = bestScore;
      try {
        localStorage.setItem('snake-best', bestScore);
      } catch (_) {
        // The score still works if browser storage is unavailable.
      }
    }
    placeFood();
  } else {
    snake.pop();
  }
  draw();
}

function endGame() {
  gameOver = true;
  messageTitle.textContent = 'Game over';
  messageText.textContent = `Your score: ${score}`;
  message.hidden = false;
}

function draw() {
  ctx.fillStyle = '#10231d';
  ctx.fillRect(0, 0, canvas.width, canvas.height);

  ctx.strokeStyle = '#ffffff08';
  ctx.lineWidth = 1;
  for (let i = 1; i < cells; i += 1) {
    ctx.beginPath();
    ctx.moveTo(i * cellSize, 0);
    ctx.lineTo(i * cellSize, canvas.height);
    ctx.moveTo(0, i * cellSize);
    ctx.lineTo(canvas.width, i * cellSize);
    ctx.stroke();
  }

  ctx.fillStyle = '#ff7b69';
  ctx.beginPath();
  ctx.arc(food.x * cellSize + cellSize / 2, food.y * cellSize + cellSize / 2, 7, 0, Math.PI * 2);
  ctx.fill();

  snake.forEach((part, index) => {
    ctx.fillStyle = index === 0 ? '#d0ffad' : '#84cb83';
    ctx.beginPath();
    ctx.roundRect(part.x * cellSize + 2, part.y * cellSize + 2, cellSize - 4, cellSize - 4, 5);
    ctx.fill();
  });
}

const keyDirections = {
  ArrowUp: [0, -1], w: [0, -1], W: [0, -1],
  ArrowDown: [0, 1], s: [0, 1], S: [0, 1],
  ArrowLeft: [-1, 0], a: [-1, 0], A: [-1, 0],
  ArrowRight: [1, 0], d: [1, 0], D: [1, 0]
};

document.addEventListener('keydown', (event) => {
  if (event.code === 'Space' && gameOver) {
    resetGame();
    return;
  }
  const move = keyDirections[event.key];
  if (move) {
    event.preventDefault();
    setDirection(move[0], move[1]);
  }
});

document.querySelectorAll('[data-direction]').forEach((button) => {
  button.addEventListener('click', () => {
    const moves = {
      up: [0, -1], down: [0, 1], left: [-1, 0], right: [1, 0]
    };
    const move = moves[button.dataset.direction];
    setDirection(move[0], move[1]);
  });
});

document.getElementById('playAgain').addEventListener('click', resetGame);

function gameLoop(timestamp) {
  if (!gameOver && timestamp - lastTick >= tickLength) {
    step();
    lastTick = timestamp;
  }
  requestAnimationFrame(gameLoop);
}

resetGame();
requestAnimationFrame(gameLoop);